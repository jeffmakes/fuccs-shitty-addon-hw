Substrate: 0.8mm FR4
Soldermask: Blue both sides
Legend: White both sides

Critical changes made to 
B.Cu bottom copper
B.Mask bottom mask

Cosmetic changes made to 
B.Silk
(can be excluded from production if need be to complete by end of Monday)

Any questions, please call Jeff Gough on +447903005844

