Substrate: 1.6mm FR4
Soldermask: Blue both sides
Legend: White both sides
Any questions, please call Jeff Gough on +447903005844

